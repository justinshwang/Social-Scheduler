import cv2
import numpy as np
import pytesseract
from PIL import Image
from pytesseract import image_to_string

#Read image in black and white
img = cv2.imread("letterImage.JPG", 1)
(col, row, ch) = img.shape

# Path of working folder on Disk
src_path = "tes-img/"

def get_string(img_path):
    # Read image with opencv
    img = cv2.imread(img_path)

    # Convert to gray
    img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Apply dilation and erosion to remove some noise
    kernel = np.ones((1, 1), np.uint8)
    img = cv2.dilate(img, kernel, iterations=1)
    img = cv2.erode(img, kernel, iterations=1)

    # Write image after removed noise
    cv2.imwrite(src_path + "removed_noise.png", img)

    #  Apply threshold to get image with only black and white
    #img = cv2.adaptiveThreshold(img, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 31, 2)

    # Write the image after apply opencv to do some ...
    cv2.imwrite(src_path + "thres.png", img)

    # Recognize text with tesseract for python
    result = pytesseract.image_to_string(Image.open(src_path + "thres.png"))

    # Remove template file
    #os.remove(temp)

    return result


print('--- Start recognize text from image ---')
print(get_string(src_path + "cont.jpg") )

print("------ Done -------")

cv2.imshow("image", median)
cv2.waitKey(0)


 
# #Difference to/from a white and black color
# lowCount = 0
# uppCount = 0
# rLower = []
# gLower = []
# bLower = []
# rUpper = []
# gUpper = []
# bUpper = []
# for r in range(0, row):
#     for c in range(0, col):
#         red,gre,blu = img[c][r]
#         if red > 0 or gre > 0 or blu > 0:
#             rLower.append(red)
#             gLower.append(gre)
#             bLower.append(blu)
#             lowCount += 1
#         if red < 255 or gre < 255 or blu < 255:
#             rUpper.append(red)
#             gUpper.append(gre)
#             bUpper.append(blu)
#             uppCount += 1
#         
# #Find upper and lower percentile of colors
# rLower.sort()
# gLower.sort()
# bLower.sort()
# 
# lowPartialCount = lowCount // 3
# uppPartialCount = uppCount // 4
# 
# #Find average "minimum" and "maximum" value that is not black or equal to 0
# minRed = 0
# minBlue = 0
# minGreen = 0
# maxRed = 0
# maxBlue = 0
# maxGreen = 0
# for i in range(lowPartialCount):
#     minRed += rLower[i]
#     minBlue += bLower[i]
#     minGreen += gLower[i]
# for i in range(uppCount - uppPartialCount, uppCount):
#     maxRed += rUpper[i]
#     maxBlue += bUpper[i]
#     maxGreen += gUpper[i]
#     
# minRed /= lowPartialCount
# minBlue /= lowPartialCount
# minGreen /= lowPartialCount
# maxRed /= uppPartialCount
# maxBlue /= uppPartialCount
# maxGreen /= uppPartialCount
#     
# for r in range(0, row):
#     for c in range(0, col):
#         red,gre,blu = img[c][r]
#         if minRed < red < 255 - maxRed or minGreen < gre < 255 - maxGreen or minBlue < blu < 255 - maxBlue:
#             #Set these "grey" colors to white - we only want the letters, which are black
#             img[c,r] = [ 255, 255, 255]        
#             
# #Or, img.itemset((1000,1000, 2), 255): red value is 255
# 
# #Find boundaries of first shape -- hardcode
# pts1 = np.float32([[40,65],[100,75],[20,390],[389,390]])
# pts2 = np.float32([[0,0],[400,0],[0,400],[400,400]])
# 
# #Calculate rotation needed by lining up edges, currently hardcoded to 5 degrees
# M = cv2.getRotationMatrix2D((col / 2,row / 2), 5, 1)
# 
# # M = cv2.getPerspectiveTransform(pts1,pts2)
#             
# dst = cv2.warpAffine(img,M,(col,row))
# 
# #Blur image with median
# median = cv2.medianBlur(dst, 6)
# 
# #https://www.pyimagesearch.com/2018/09/17/opencv-ocr-and-text-recognition-with-tesseract/
# 

