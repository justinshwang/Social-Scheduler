import calendar, datetime, math, string
from tkinter import *
## Global Variables##


##########################
#Profile Class
##########################

#Describes each person's profile
class Profile(object):

    def __init__(self, name, disturb, calendar):
        self.name = name
        self.calendar = Calendar(calendar)
        self.doNotDisturb = disturb
        self.available = True


##########################
#Calendar Class
##########################

#Describes a schedule
class Calendar(object):
    #Store formatted calendar as well as current date and time
    def __init__(self, schedule):
        today = datetime.date.today()
        self.year = today.year
        self.day = today.day
        self.month = today.month
        self.weekDay = today.weekday()
        self.schedule = self.format(schedule)
        
    
    #Format marked calendar dates into a dictionary
    def format(self, schedule):
        #Read file - Function
        sch = dict()
        return sch
        
    def drawCal(self, x, y, canvas):
        t = datetime.datetime.now()
        self.hour = t.hour
        self.minute = t.minute
        #Format this for better calendar
        canvas.create_text(x, y, text = calendar.month(self.year, self.month), \
        anchor = "center", justify = "center")
        

        