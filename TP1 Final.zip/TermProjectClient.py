#############################
# Sockets Client Demo
# by Rohan Varma
# adapted by Kyle Chin
#############################

import socket
import threading
from queue import Queue

HOST = "128.237.129.1" # put your IP address here if playing on multiple computers
PORT = 50340

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server.connect((HOST,PORT))
print("connected to server")

def handleServerMsg(server, serverMsg):
  server.setblocking(1)
  msg = ""
  command = ""
  while True:
    msg += server.recv(10).decode("UTF-8")
    command = msg.split("\n")
    while (len(command) > 1):
      readyMsg = command[0]
      msg = "\n".join(command[1:])
      serverMsg.put(readyMsg)
      command = msg.split("\n")

# events-example0.py from 15-112 website
# Barebones timer, mouse, and keyboard events

from tkinter import *
from Meet import *
import random

####################################
# Function specific to Meet Application
####################################

def init(data):
    name = input("Enter your name: ") 
    calendar = input("Enter file name for schedule: ")
    disturb = False
    data.me = Profile(name, disturb, calendar)
    data.otherFriends = dict()
    data.mode = "Home"
    data.optionsMode = "Closed"

def mousePressed(event, data):
    msg = ""
    x, y = event.x, event.y
    
    #If do not disturb button is pressed, change disturb mode
    margin = data.width / 10
    diX = data.me.disturb.x
    diY = data.me.disturb.y
    if diX - margin < x < diX + margin:
      if diY - margin < y < diY + margin:
        data.doNotDisturb = not data.doNotDisturb
        msg = "disturb" + " " + data.me.name 

    if data.mode == "Home":
      homeMousePressed(event, data)
    elif data.mode == "Calendar":
      calMousePressed(event, data)
    elif data.mode == "Meet":
      meetMousePressed(event,data)
    
    # send the message to other players!
    if (msg != ""):
      print ("sending: ", msg,)
      data.server.send(msg.encode())


def keyPressed(event, data):
    if data.mode == "Home":
      homeKeyPressed(event, data)
    elif data.mode == "Calendar":
      calKeyPressed(event, data)
    elif data.mode == "Meet":
      meetKeyPressed(event,data)
      

def timerFired(data):
    while (serverMsg.qsize() > 0):
          msg = serverMsg.get(False)
          try:
            print("received: ", msg, "\n")
            msg = msg.split()
            command = msg[0]
            
            if command == "disturb":
              name = msg[1]
              data.otherFriends[name].doNotDisturb = not data.otherFriends[name].doNotDisturb
            elif command == "newFriend"
              name = msg[1]
              disturb = msg[2]
              calendar = msg[3]
              data.otherFriends[name] = Profile(name, disturb calendar)
              
    if data.mode == "Home":
      homeTimerFired(data)
    elif data.mode == "Calendar":
      calTimerFired(data)
    elif data.mode == "Meet":
      meetTimerFired(data)
      
#Draw Do Not Disturb icon
def drawDisturb(data, canvas):
    if data.me.doNotDisturb:
        disturb = "N"
    else:
        disturb = "Y"
    cx = data.width - data.width / 10
    cy = data.width / 5
    canvas.create_text(cx, cy, text = disturb)
    
    
#Draw indicator for whether or not currently available      
def drawAvailable(data, canvas):
    if data.me.available:
        color = "green"
    else:
        color = "red"
    r = data.width / 25
    cx = data.width - data.width / 10 
    cy = data.width / 10
    canvas.create_oval(cx - r, cy - r, cx + r, cy + r, fill = color)

def redrawAll(canvas, data):
    canvas.create_text(3 * data.width / 4, data.height / 15, text = data.me.name, anchor = "w")
    #"Meet" drawn at top at all times
    canvas.create_text(data.width / 2, data.height / 10, text = "MEET")
    #Draw availability and do not disturb indicators in top right
    drawAvailable(canvas, data)
    drawDisturb(canvas, data)
    tabHeight = data.height - data.height / 8
    #Draw Calendar button
    c1 = data.width + data.width / 10
    c2 = data.width / 3 - data.width / 10
    canvas.create_line(c1, tabHeight, c2, tabHeight)
    #Draw Meet Today button
    t1 = data.width / 3 + data.width / 10
    t2 = data.width * 2 / 3 - data.width / 10
    canvas.create_line(t1, tabHeight, t2, tabHeight)
    #Draw Meet Friends button
    f1 = data.width * 2 / 3 + data.width / 10
    f2 = data.width - data.width / 10
    canvas.create_line(f1, tabHeight, f2, tabHeight)
    
    ##MOVE to "Meet" mode only eventually
    # draw other players
    for name in data.otherFriends:
      data.otherFriends[name].drawDisturb(canvas, data)
      
    if data.mode == "Home":
      homeRedrawAll(canvas, data)
    elif data.mode == "Calendar":
      calRedrawAll(canvas, data)
    elif data.mode == "Meet":
      meetRedrawAll(canvas,data)
      
     
## HOME PAGE ##

def homeKeyPressed(event, data):
    pass
    
def homeMousePressed(event, data):
    pass
  
def homeTimerFired(data):
    # timerFired receives instructions and executes them
    while (serverMsg.qsize() > 0):
      msg = serverMsg.get(False)
      try:
        msg = msg.split()
        command = msg[0]

        if (command == ""):
          myPID = msg[1]
          data.me.changePID(myPID)

      except:
        print("failed")
      serverMsg.task_done()

def homeRedrawAll(canvas, data):
  #Draw date
  date = "Today is " + data.me.calendar.month + " " + data.me.calendar.day
  canvas.create_text(data.width / 2, data.height / 8, text = date)
  canvas.create_rectangle(0,0, data.width / 2, data.height / 2)
  
  
  
## CALENDAR PAGE ##

def calKeyPressed(event, data):
  pass

def calMousePressed(event, data):
  pass
  
def calTimerFired(data):
  pass
  
def calRedrawAll(canvas, data):
  data.me.calendar.drawCal(data.width / 2, data.height / 2)
  canvas.create_rectangle(data.width / 4, data.height / 4, 3 * data.width / 4, 3 * data.height / 4)
  
  
  
## MEET PAGE ##

def meetKeyPressed(event, data):
  pass

def meetMousePressed(event, data):
  pass
  
def meetTimerFired(data):
  pass
  
def meetRedrawAll(canvas, data):
  canvas.create_rectangle(0,0, data.width / 2, data.height / 2)
  
  
####################################
# use the run function as-is
####################################

def run(width, height, serverMsg=None, server=None):
    def redrawAllWrapper(canvas, data):
        canvas.delete(ALL)
        redrawAll(canvas, data)
        canvas.update()

    def mousePressedWrapper(event, canvas, data):
        mousePressed(event, data)
        redrawAllWrapper(canvas, data)

    def keyPressedWrapper(event, canvas, data):
        keyPressed(event, data)
        redrawAllWrapper(canvas, data)

    def timerFiredWrapper(canvas, data):
        timerFired(data)
        redrawAllWrapper(canvas, data)
        # pause, then call timerFired again
        canvas.after(data.timerDelay, timerFiredWrapper, canvas, data)
    # Set up data and call init
    class Struct(object): pass
    data = Struct()
    data.server = server
    data.serverMsg = serverMsg
    data.width = width
    data.height = height
    data.timerDelay = 100 # milliseconds
    init(data)
    # create the root and the canvas
    root = Tk()
    canvas = Canvas(root, width=data.width, height=data.height)
    canvas.pack()
    # set up events
    root.bind("<Button-1>", lambda event:
                            mousePressedWrapper(event, canvas, data))
    root.bind("<Key>", lambda event:
                            keyPressedWrapper(event, canvas, data))
    timerFiredWrapper(canvas, data)
    # and launch the app
    root.mainloop()  # blocks until window is closed
    print("bye!")

serverMsg = Queue(100)
threading.Thread(target = handleServerMsg, args = (server, serverMsg)).start()

run(200, 600, serverMsg, server)