�Meet� is an application in which users upload their personal schedules and find different �meet up� times based on their availability via various 
features for socializing and communicating. For example, a colored indicator will represent current availability (either available or not available) 
and users will be able to manipulate availability spontaneously should an emergency arise or if they simply need �personal time.� Users can also indicate
 how they would prefer to spend certain times of the day for different activities such as �socializing�, �work�, �sleeping,� and �eating�.

From Pyzo, the user can run the TermProjectServer file. Before launching clients, ensure that client IP matches that of server, then launch TermProjectClient 
(both on two seperate command prompts/Terminals if on same device)  on a command prompt/Terminal. image_util and other necessary files are included in folder.
Next, on the same command prompt or window, enter Name (which must be Eric and subsequently for other user Justin), press enter; enter schedule files. For schedule files 
already included, enter "schedule1.txt" and for the other user "schedule2.txt".