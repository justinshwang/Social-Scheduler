#############################
# Sockets Client Demo
# by Rohan Varma
# adapted by Kyle Chin
#############################

import socket
import threading
from queue import Queue

HOST = "128.237.119.243" # put your IP address here if playing on multiple computers
PORT = 50340

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server.connect((HOST,PORT))
print("connected to server")

def handleServerMsg(server, serverMsg):
  server.setblocking(1)
  msg = ""
  command = ""
  while True:
    msg += server.recv(10).decode("UTF-8")
    command = msg.split("\n")
    while (len(command) > 1):
      readyMsg = command[0]
      msg = "\n".join(command[1:])
      serverMsg.put(readyMsg)
      command = msg.split("\n")

# events-example0.py from 15-112 website
# Barebones timer, mouse, and keyboard events

#image_util import taken from 15112 site
import random, math, copy, string, ast
from tkinter import*
from image_util import*
from Meet import *

####################################
# Function specific to Meet Application
####################################

def init(data):
  name = input("Please enter your name: ") 
  calendar = input("Enter file name for schedule: ")
  disturb = False
  data.me = Profile(name, disturb, calendar)
  data.otherFriends = dict()
  data.mode = "Home"
  data.optionsMode = "Closed"
  
  #Tab icons       
  data.meetImage = PhotoImage(file="meet.gif")
  data.homeImage = PhotoImage(file="home.gif")
  data.calImage = PhotoImage(file="calendar.gif")
  
  #Calendar mode
  data.calMode = "cal"
  
  #Meet mode
  data.drawMeetButton = False
  
## PRIMARY CONTROLLERS ##

def mousePressed(event, data):
  msg = ""
  x, y = event.x, event.y
  
  margin = data.width / 10
  diX = data.width - data.width / 10
  diY = data.width / 5
  tabHeight = data.height - data.height / 8
  if diX - margin < x < diX + margin and diY - margin < y < diY + margin:
    #If do not disturb button is pressed, change mode
    data.me.doNotDisturb = not data.me.doNotDisturb
    msg = "disturb %s\n" % data.me.name  
  elif 0 <= x < data.width / 3 and tabHeight <= y <= data.height:
    #Change mode to calendar
    data.mode = "Calendar"
  elif data.width / 3 <= x < 2 * data.width / 3 and tabHeight <= y <= data.height:
    #Change mode to Home
    data.mode = "Home"
  elif data.width * 2 / 3 <= x <= data.width and tabHeight <= y <= data.height:
    #Change mode to Meet
    data.mode = "Meet"
  # send the message to other players!
  if (msg != ""):
    print ("sending: ", msg)
    data.server.send(msg.encode())
    
  if data.mode == "Home":
    homeMousePressed(event, data)
  elif data.mode == "Calendar":
    calMousePressed(event, data)
  elif data.mode == "Meet":
    meetMousePressed(event,data)
    
def keyPressed(event, data):
  if data.mode == "Home":
    homeKeyPressed(event, data)
  elif data.mode == "Calendar":
    calKeyPressed(event, data)
  elif data.mode == "Meet":
    meetKeyPressed(event,data)
      

def timerFired(data):
  while (serverMsg.qsize() > 0):
    msg = serverMsg.get(False)
    try:
      print("received: ", msg, "\n")
      msg = msg.split()
      command = msg[0]
      
      if command == "disturb":
        name = msg[1]
        data.otherFriends[name].doNotDisturb = not data.otherFriends[name].doNotDisturb
      elif command == "newFriend":
        name = msg[1]
        disturb = False
        addNewClient(data, name)
      elif command == "myIDis":
        myName = msg[1]
        data.me.name = myName
      elif command == "giveMeSchedule":
        name = msg[1]
        sendSchedule(data, name)
      elif command == "saveThisSchedule":
        name = msg[1]
        #Interprets string representation of dictionary
        schedule = ast.literal_eval(msg[2])
        print("SENT", name)
        print()
        data.otherFriends[name] = Profile(name, True, schedule)
      elif command == "success":
        fullMsg = msg[1]
        #Print this message 
      elif command == "newTime":
        #Suggest a new time
        pass
      elif command == "fail":
        #Suggest a time given priorities
        pass
    except:
      print("failed")
    serverMsg.task_done()
    
  if data.mode == "Home":
    homeTimerFired(data)
  elif data.mode == "Calendar":
    calTimerFired(data)
  elif data.mode == "Meet":
    meetTimerFired(data)

def redrawAll(canvas, data):
  canvas.create_text(4 * data.width / 5, data.height / 15, text = data.me.name, anchor = "e")
  #"Meet" drawn at top at all times
  canvas.create_text(data.width / 2, data.height / 15, text = "MEET", font = ("helvetica", 14, "bold"))
  #Draw availability and do not disturb indicators in top right
  drawAvailable(canvas, data)
  drawDisturb(canvas, data)
  margin = data.width / 10
  tabHeight = data.height - data.height / 8
  
  #Draw Calendar button
  c1 = margin
  c2 = data.width / 3 - margin
  calImageX = (data.width / 3) / 2
  calImageY = tabHeight + ((data.height - tabHeight) / 2)
  canvas.create_line(c1, tabHeight, c2, tabHeight)
  canvas.create_image(calImageX, calImageY, anchor="center", image=data.calImage)
    
  #Draw Home button
  h1 = data.width / 3 + margin
  h2 = data.width * 2 / 3 - margin
  homeImageX = (data.width / 3) + (data.width / 3) / 2
  homeImageY = tabHeight + (data.height - tabHeight) / 2
  canvas.create_line(h1, tabHeight, h2, tabHeight)
  canvas.create_image(homeImageX, homeImageY, anchor="center", image=data.homeImage)
  
  #Draw Meet Friends button
  f1 = data.width * 2 / 3 + margin
  f2 = data.width - margin
  meetImageX = data.width - ((data.width / 3) / 2)
  meetImageY = tabHeight + ((data.height - tabHeight) / 2)
  canvas.create_line(f1, tabHeight, f2, tabHeight)
  canvas.create_image(meetImageX, meetImageY, anchor="center", image=data.meetImage)
  
  if data.mode == "Home":
    homeRedrawAll(canvas, data)
  elif data.mode == "Calendar":
    calRedrawAll(canvas, data)
  elif data.mode == "Meet":
    meetRedrawAll(canvas,data)
    
## GENERAL FUNCTIONS ##

#Draw Do Not Disturb icon
def drawDisturb(canvas, data):
  if data.me.doNotDisturb:
      disturb = "N"
  else:
      disturb = "Y"
  cx = data.width - data.width / 10
  cy = data.width / 5
  canvas.create_text(cx, cy, text = disturb)
        
#Draw indicator for whether or not currently available      
def drawAvailable(canvas, data):
  if data.me.available:
      color = "green"
  else:
      color = "red"
  r = data.width / 25
  cx = data.width - data.width / 10 
  cy = data.width / 10
  canvas.create_oval(cx - r, cy - r, cx + r, cy + r, fill = color)
  
#Sends message asking for schedule
def addNewClient(data, name):
  msg = ""
  msg = "giveMeSchedule" + " " + name + "\n"
  if (msg != ""):
    print ("sending: ", msg)
    data.server.send(msg.encode())
  
#Sends user schedule to another
def sendSchedule(data, name):
  msg = ""
  msg = "saveThisSchedule" + " " + name + " " + str(data.me.calendar.schedule) + "\n"
  if (msg != ""):
    print ("sending: ", msg)
    data.server.send(msg.encode())
     
## HOME PAGE ##

def homeKeyPressed(event, data):
    pass
    
def homeMousePressed(event, data):
    pass
  
def homeTimerFired(data):
    pass

def homeRedrawAll(canvas, data):
  #Draw date heading
  date = "'TODAY " + str(data.me.calendar.month) + " / " + str(data.me.calendar.day) + "'"
  canvas.create_text(data.width / 2, data.height / 8, text = str(date), font = ("hervetica", 10, "bold"))
  
## CALENDAR PAGE ##

def calKeyPressed(event, data):
  pass

def calMousePressed(event, data):
  x,y = event.x, event.y
  
  #Button locations for adding or deleting date
  margin = data.width / 10
  tabHeight = data.height - data.height / 8
  bLeft = margin + data.height / 20
  bBottom = tabHeight - data.height / 20
  bWidth = data.width / 10
  bHeight = data.height / 20
  
  #Implement functionality for users to add new events in manually
  # if data.calMode == "cal":
  #   if bLeft < x < bLeft + bWidth and bBottom - bHeight < y < bBottom:
  #     data.calMode = "choose"
  # elif data.calMode == "choose":
  #   pass
  # elif data.calMode == "set":
  #   pass
  
def calTimerFired(data):
  pass
  
def calRedrawAll(canvas, data):
  #Draw calendar heading
  margin = data.width / 10
  tabHeight = data.height - data.height / 8
  data.me.calendar.drawCal(canvas, data.width / 2, (data.height / 2) - margin)
  canvas.create_rectangle(margin, data.height / 5, data.width - margin, tabHeight - margin)
  canvas.create_text(data.width / 2, data.height / 8, text = "''CALENDAR''", font = ("hervetica", 10, "bold")) 
   
  #Button for scheduling "add"
  buttonMargin = data.height / 30
  bLeft = margin + buttonMargin
  bBottom = tabHeight - margin - buttonMargin
  bWidth = data.width / 10
  bHeight = data.height / 20
  canvas.create_rectangle(bLeft, bBottom - bHeight, (data.width / 2) - buttonMargin, bBottom, fill = "white")
  canvas.create_text((bLeft + (data.width / 2 - buttonMargin)) / 2, bBottom - bHeight / 2, text = "Add", anchor = "center", font = ("hervetica", 11, "bold"))
  
  #Button for scheduling "Delete"
  #Currently not implemented (not active)
  bRight = data.width - margin - buttonMargin
  canvas.create_rectangle(data.width / 2 + buttonMargin, bBottom - bHeight, bRight, bBottom, fill = "white")
  canvas.create_text(((data.width / 2 + buttonMargin) + bRight) / 2, bBottom - bHeight / 2, text = "Delete", anchor = "center", font = ("hervetica", 11, "bold"))
  
  if data.calMode == "choose":
    pass
  if data.calMode == "set":
    pass
  
## MEET PAGE ##

def meetKeyPressed(event, data):
  pass

def meetMousePressed(event, data):
  x, y = event.x, event.y
  
  #If user clicks line of that friend, ask for a date, times, priority (or None as default), and description
  indent = data.height / 20
  top = data.height / 5
  margin = data.width / 10
  
  if len(data.otherFriends) > 0:
    if margin < x < data.width - margin:
      if (y - top) // indent < len(data.otherFriends):
        friendNum = (y - top) // indent       
        friend = data.otherFriends(friendNum)
        
        #Temporary data variables that store user input
        data.drawMeetButton = True
        data.meetName = friend
        data.meetMonth = ""
        data.meetDate = ""
        data.meetStart = ""
        data.meetEnd = ""
        data.meetPriority = ""
        data.meetMsg = ""
        while data.drawMeetButton:
          if data.meetMonth == "":
            data.meetMonth = input("Enter Month: ")
          elif data.meetDate == "":
            data.meetDate = input("Enter day: ")
          elif data.meetStart == "":
            time = input("Enter start time: ")
            time = time.split(":")
            hr = time[0]
            min = time[1]
            timeFormatted = hr + min
            data.meetStart = timeFormatted
          elif data.meetEnd == "":
            time = input("Enter end time: ")
            time = time.split(":")
            hr = time[0]
            min = time[1]
            timeFormatted = hr + min
            data.meetEnd = timeFormatted
          elif data.meetPriority == "":
            data.meetPriority = input("Enter priority: ")
          elif data.meetMsg == "":
            data.meetMsg = input("Enter message: ")
          else:
            data.drawMeetButton = False
  
def meetTimerFired(data):
  pass
  
def meetRedrawAll(canvas, data):
  #Draw meet heading
  margin = data.width / 10
  tabHeight = data.height - data.height / 8
  left = margin
  top = data.height / 5
  right = data.width - margin
  bottom = tabHeight - margin
  canvas.create_text(data.width / 2, data.height / 8, text = "'UP'", font = ("hervetica", 10, "bold"))
  
  #Draw friends' current availabilities
  xName = left
  xIndicator = right
  y = top 
  #Count used to track indentation amount
  count = 1
  for name in data.otherFriends:
    if data.otherFriends[name].doNotDisturb == True:
      disturb = "Y"
    else:
      disturb = "N"
    indent = count * data.height / 20
    canvas.create_text(xIndicator, y + indent, text = disturb + "\t", anchor = "e")
    canvas.create_text(xName, y + indent, text = "\t" + (data.otherFriends[name].name + ": "), anchor = "w")
    canvas.create_line(left, top + indent, right, top + indent, width = 2)
    count += 1
  if data.drawMeetButton:
    drawButton(canvas, data)
    
#Draws button prompting user input
def drawButton(canvas, data):
  left = data.width / 4
  right = data.width * 3 / 4
  top = data.height / 5
  bottom = data.height * 2 / 5
  margin = data.height / 20
  canvas.create_rectangle(left, top, right, bottom, fill = "white")
  canvas.create_text(left, top + margin, text = "\t" + "Month: " + str(data.meetMonth), font = ("hervetica", 11), anchor = "w")
  canvas.create_text(left, top + margin * 2, text = "\t" + "Day: " + str(data.meetDate), font = ("hervetica", 11), anchor = "w")
  canvas.create_text(left, top + margin * 3, text = "\t" + "Start time: " + str(data.meetStart), font = ("hervetica", 11), anchor = "w")
  canvas.create_text(left, top + margin * 4, text = "\t" + "End time: " + str(data.meetEnd), font = ("hervetica", 11), anchor = "w")
  canvas.create_text(left, top + margin * 5, text = "\t" + "Priority: " + str(data.meetPriority), font = ("hervetica", 11), anchor = "w")
  canvas.create_text(left, top + margin * 6, text = "\t" + "Description: " + str(data.meetMsg), font = ("hervetica", 11), anchor = "w")
  
#Returns dictionary as list with tuple storing ninformatio on meeting time and message
def recommendTime(data, friendName):
  msg = ""
  #First checks to see if given time works as suggested
  for time in data.me.calendar[(data.meetMonth, data.meetDay)]:
    type, priority, start, end = time
    if start <= data.meetStart <= end:
      msg = "Times do not work out!"
      return ("fail", msg)
  msg = "Time works perfectly"
  return ("success", msg)
  
  ##Finish basic scheduling between two people (add priorities)
  #Add this event to schedule if a success
  #Success, msg = recommendTime(data, friendName) 

  
####################################
# use the run function as-is - framework taken from 15112 website
####################################

def run(width, height, serverMsg = None, server = None):
    def redrawAllWrapper(canvas, data):
        canvas.delete(ALL)
        canvas.create_rectangle(0, 0, data.width, data.height,
                                fill='white', width=0)
        redrawAll(canvas, data)
        canvas.update()

    def mousePressedWrapper(event, canvas, data):
        mousePressed(event, data)
        redrawAllWrapper(canvas, data)

    def keyPressedWrapper(event, canvas, data):
        keyPressed(event, data)
        redrawAllWrapper(canvas, data)

    def timerFiredWrapper(canvas, data):
        timerFired(data)
        redrawAllWrapper(canvas, data)
        # pause, then call timerFired again
        canvas.after(data.timerDelay, timerFiredWrapper, canvas, data)
    # Create root before calling init (so we can create images in init)
    root = Tk()
    # Set up data and call init
    class Struct(object): pass
    data = Struct()
    data.server = server
    data.serverMsg = serverMsg
    data.width = width
    data.height = height
    data.timerDelay = 250 # milliseconds
    init(data)
    # create the root and the canvas
    canvas = Canvas(root, width=data.width, height=data.height)
    canvas.pack()
    # set up events
    root.bind("<Button-1>", lambda event:
                            mousePressedWrapper(event, canvas, data))
    root.bind("<Key>", lambda event:
                            keyPressedWrapper(event, canvas, data))
    timerFiredWrapper(canvas, data)
    # and launch the app
    root.mainloop()  # blocks until window is closed
    print("bye!")

serverMsg = Queue(100)
threading.Thread(target = handleServerMsg, args = (server, serverMsg)).start()

run(400, 600, serverMsg, server)